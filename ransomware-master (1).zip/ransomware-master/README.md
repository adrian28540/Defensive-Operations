#Ransomware

This script performs encryption on the specified path and all its subdirectories.

# Dependencies

You will need to install the following dependencies:

```
$ pip install pycryptodome
```