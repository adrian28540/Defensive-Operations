from eip import PLC
import time
with PLC() as test:
	test.IPAddress = "172.30.10.11"
comm = PLC()
val = (float(1))
comm.Write("Filter_1_influent_valve.OCmd_close", val)	
print "Filter 1 Influent Valve Command has been set to Close"
time.sleep(5)

