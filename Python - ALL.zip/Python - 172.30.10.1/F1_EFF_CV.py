from eip import PLC
import time
with PLC() as test:
	test.IPAddress = "172.30.10.1"
comm = PLC()
print "Filter 1 Level Output Command is % 4f" % test.Read("Filter_1_Effluent_Flow_Control.OSet_CV")
n = raw_input("Please enter a new value: ")
val = (float(n))
comm.Write("Filter_1_Effluent_Flow_Control.OCmd_Man", "1")
comm.Write("Filter_1_Effluent_Flow_Control.Oset_CV", val)	
print "Filter 1 Level Output Command has been set to % 4f" % test.Read("Filter_1_Effluent_Flow_Control.OSet_CV")
time.sleep(5)

