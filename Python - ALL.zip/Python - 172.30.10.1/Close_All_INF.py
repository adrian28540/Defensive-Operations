from eip import PLC
import time
with PLC() as test:
	test.IPAddress = "172.30.10.1"
comm = PLC()
val = (float(1))
comm.Write("Filter_1_influent_valve.OCmd_close", val)

comm.Write("Filter_2_influent_valve.OCmd_close", val)

comm.Write("Filter_3_influent_valve.OCmd_close", val)

comm.Write("Filter_4_influent_valve.OCmd_close", val)

comm.Write("Filter_5_influent_valve.OCmd_close", val)
print "Filters 1-5 Influent Valve Command has been set to Close" 
time.sleep(5)

