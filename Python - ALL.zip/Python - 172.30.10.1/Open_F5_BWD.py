from eip import PLC
import time
with PLC() as test:
	test.IPAddress = "172.30.10.1"
comm = PLC()
val = (float(1))
comm.Write("Filter_5_BW_Drain_Valve.OCmd_Open", val)	
print "Filter 5 Backwash Drain Valve Open Command has been set to open"
time.sleep(5)

