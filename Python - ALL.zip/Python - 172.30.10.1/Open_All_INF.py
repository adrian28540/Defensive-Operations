from eip import PLC
import time
with PLC() as test:
	test.IPAddress = "172.30.10.1"
comm = PLC()
val = (float(1))
comm.Write("Filter_1_influent_valve.OCmd_open", val)

comm.Write("Filter_2_influent_valve.OCmd_open", val)

comm.Write("Filter_3_influent_valve.OCmd_open", val)

comm.Write("Filter_4_influent_valve.OCmd_open", val)

comm.Write("Filter_5_influent_valve.OCmd_open", val)
print "All Filter Influent Valve Commands have been set to Open"
time.sleep(5)

