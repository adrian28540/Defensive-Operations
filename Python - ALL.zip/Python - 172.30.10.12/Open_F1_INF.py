from eip import PLC
import time
with PLC() as test:
	test.IPAddress = "172.30.10.12"
comm = PLC()
val = (float(1))
comm.Write("Filter_1_influent_valve.OCmd_Open", val)	
print "Filter 1 Influent Valve Open Command has been set to open"
time.sleep(5)



