from eip import PLC
import time
with PLC() as test:
	test.IPAddress = "172.30.10.12"
comm = PLC()
val = (float(1))
comm.Write("Filter_1_Influent_Valve.OCmd_Open", val)	
time.sleep(1)
comm.Write("Filter_2_Influent_Valve.OCmd_Open", val)
time.sleep(1)
comm.Write("Filter_3_Influent_Valve.OCmd_Open", val)
time.sleep(1)
comm.Write("Filter_4_Influent_Valve.OCmd_Open", val)
time.sleep(1)
comm.Write("Filter_5_Influent_Valve.OCmd_Open", val)
print "Influents Open!"
time.sleep(1)
comm.Write("Filter_5_BW_Drain_Valve.OCmd_Close", val)
time.sleep(1)
comm.Write("Filter_4_BW_Drain_Valve.OCmd_Close", val)
time.sleep(1)
comm.Write("Filter_3_BW_Drain_Valve.OCmd_Close", val)
print "Drains Closed!"
time.sleep(15)
