from eip import PLC
import time
with PLC() as test:
	test.IPAddress = "172.30.10.12"
comm = PLC()
val = (float(1))
comm.Write("Filter_5_BW_Drain_Valve.OCmd_Close", val)	
print "Filter 5 Backwash Drain Valve Open Command has been set to close"
time.sleep(5)

