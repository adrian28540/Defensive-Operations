from eip import PLC
import time
with PLC() as test:
	test.IPAddress = "172.30.10.12"
comm = PLC()
ret = comm.GetTagList()
with open("TagList.txt", "w") as text_file: 
	for tag in ret:
		name = "Name: " + tag.TagName
		dtype = "Type: " + str(tag.DataType)
		offset= "Offset: " + str(tag.Offset)
		end = '\n'
		#clean up tab settings for readability
		if len(name) >= 30: tabs = '\t'
      		if len(name) < 30 and len(name) >= 24: tabs = '\t'*2
      		if len(name) < 24 and len(name) >= 16: tabs = '\t'*3
     		if len(name) < 16 and len(name) >= 8: tabs = '\t'*4
      		if len(name) < 8: tabs = '\t'*5		
		if len(dtype) < 8: tabs2 = '\t'*2
		if len(dtype) >=8: tabs2 = '\t'
        	line = name + tabs + dtype + tabs2 + offset + end
		text_file.write(line)

a=0; b=100
while a < b:
    print "Thank you for sharing your database with me! We are ANONYMOUS."
    a += 1
time.sleep(2)
print "Files Done!"
time.sleep(15)
