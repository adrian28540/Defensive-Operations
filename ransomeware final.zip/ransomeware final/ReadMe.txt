ransom ware.

To run:
Right click, run as admin

This will encrypt the C drive.

 